exports.ROLES = {
    ADMIN: 'admin',
    STUDENT : 'student',
    TEACHER : 'teacher'
}

exports.COURSE_STATUS = {
    PENDING : 'pending',
    APPROVED : 'approved',
    REJECTED : 'rejected'
}