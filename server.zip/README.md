# Programming-Shikho-Server

# CHOLO PROGRAMMING SHIKHI

Live Link : https://choloprogrammingshikhi.vercel.app/
## How to Run

- Clone this repository to your local machine.
- Requires `node >= 16.0.0`.
- Run `npm install` in the root directory.
- Run `npm run start` or `npm start` in the root directory.


### How to start new task:

- Checkout to `master` branch (`git checkout master`).
- Pull from `master` (`git pull origin master`)
- Create new brach named as Your name. (`git checkout -b Sorowar`)
- After finished, do the `IMPORTANT` task below.
- Commit and make a PR(Pull Request) with `master`.
- If any `conflicts` happen, resolve `locally`.
- If you get any `review`, reply there and resolve it in a new `commit` and just `push`. NO NEED TO MAKE A NEW PR UNLESS THAT IS CLOSED.
- Once everything resolves, team leader will `approve` and `merge` the PR with main.
